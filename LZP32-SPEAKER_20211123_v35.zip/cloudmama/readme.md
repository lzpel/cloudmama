# cloudmama

日時に合わせて適切なアドバイスをGoogle Homeから再生する私的サービス

## Output

文字列

https://cloudmama.appspot.com/

文字列全パターン

https://cloudmama.appspot.com/?all=true

音声

https://cloudmama.appspot.com/speech

音声全パターン

https://cloudmama.appspot.com/speech?all=true

## ESP32 Client

[C++ Source Code](esp32/cloudmama.ino)

## License
MIT Copyright 2020 lzpel